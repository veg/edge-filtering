#!/bin/sh
cython src/datrie.pyx src/cdatrie.pxd src/stdio_ext.pxd -a